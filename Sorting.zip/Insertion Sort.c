#include<stdio.h>

void insertion(int a[], int n)
{
    int i, j, value;
    for (i=1; i<n; i++)
    {
        value = a[i];
        j = i-1;
        while ((value < a[j]) && (j>=0))
        {
            a[j+1] = a[j];
            j--;
        }
        a[j+1] = value;
        printf("Array after pass %d: ", i);
        for (j=0; j<n; j++)
            printf("%d\t", a[j]);
        printf("\n");
    }
}

int main()
{
    int i, size;
    printf("Enter array size: ");
    scanf("%d", &size);
    int arr[size];
    printf("\nEnter array elements:\n\n");
    for (i=0; i<size; i++)
        scanf("%d", &arr[i]);
    insertion(arr, size);
    return 0;
}
