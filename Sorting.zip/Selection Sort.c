#include<stdio.h>

void selection(int a[], int n)
{
    int i, j, k, min, temp;
    for (i=0; i<n; i++)
    {
        min = a[i];
        for (j=i+1; j<n; j++)
        {
            if (a[j] < min)
            {
                min = a[j];
                k = j;
            }
        }
        temp = a[i];
        a[i] = a[k];
        a[k] = temp;
        printf("Array after pass %d:\t\t", i+1);
        for (j=0; j<n; j++)
            printf("%d\t", a[j]);
        printf("\n");
    }
}

int main()
{
    int i, size;
    printf("Enter array size: ");
    scanf("%d", &size);
    int arr[size];
    printf("\nEnter array elements:\n");
    for (i=0; i<size; i++)
        scanf("%d", &arr[i]);
    selection(arr, size);
    return 0;
}
