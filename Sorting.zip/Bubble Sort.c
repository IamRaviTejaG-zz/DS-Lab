#include<stdio.h>

void bubble (int a[], int n)
{
    int i, j, temp;
    for (i=0; i<n; i++)
    {
        for (j=i; j<n; j++)
        {
            if (a[j] < a[i])
            {
                temp = a[i];
                a[i] = a[j];
                a[j] = temp;
            }
        }
        printf("Array after pass %d: ", i+1);
        for (j=0; j<n; j++)
            printf("%d\t", a[j]);
        printf("\n");
    }
}

int main()
{
    int size, i;
    printf("Enter array size: ");
    scanf("%d", &size);
    int arr[size];
    printf("\nEnter array elements:\n");
    for (i=0; i<size; i++)
        scanf("%d", &arr[i]);
    bubble(arr, size);
    return 0;
}
